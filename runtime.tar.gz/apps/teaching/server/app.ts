import { randomUUID } from 'node:crypto';
import Fastify, { LogController } from 'fastify';
import { errorDefinitions } from '../contracts/common/http.ts';
import { RunnerError } from '../runner/snapshot.ts';
import { ApiError, errorResponse, domainError } from './app/errors.ts';

import type { ServerOptions } from 'node:https';

export interface AppOptions {
  https?:Pick<ServerOptions,'key'|'cert'>;
  checkReadiness?:()=>boolean|Promise<boolean>;
  logDestination?: { write(message: string): void };
  // Current main exposes a throwing void hook; PR56 callers retain their boolean hook during integration.
  checkReady?: () => void | Promise<void>;
}

export function createApp(options: AppOptions = {}) {
  if(options.checkReadiness&&options.checkReady)throw new ApiError('INVALID_CONFIGURATION');
  const app = Fastify({
    ...(options.https ? {https:options.https} : {}),
    ajv: { customOptions: { removeAdditional: false, coerceTypes: false, useDefaults: false } },
    logger: options.logDestination ? {
      stream: options.logDestination,
      serializers: {
        err: () => ({ type: 'Error', message: 'Internal failure.', stack: '' }),
        req: (request) => ({ method: request.method }),
        res: (reply) => ({ statusCode: reply.statusCode }),
      },
    } : false,
    requestIdHeader: false,
    genReqId: () => randomUUID(),
    logController: new LogController({ disableRequestLogging: true }),
  });

  app.setErrorHandler((error, request, reply) => {
    const frameworkCode = typeof error === 'object' && error !== null && 'code' in error ? error.code : undefined;
    const code = error instanceof ApiError ? error.code : error instanceof RunnerError ? domainError(error,'DEPENDENCY_UNAVAILABLE').code
      : frameworkCode === 'FST_ERR_CTP_BODY_TOO_LARGE' ? 'CONTENT_LIMIT'
      : frameworkCode === 'FST_ERR_CTP_INVALID_JSON_BODY' || frameworkCode === 'FST_ERR_CTP_EMPTY_JSON_BODY'
        || frameworkCode === 'FST_ERR_CTP_INVALID_MEDIA_TYPE' || frameworkCode === 'FST_ERR_VALIDATION'
        ? 'INVALID_REQUEST' : 'DEPENDENCY_UNAVAILABLE';
    if (!(error instanceof ApiError) && code === 'DEPENDENCY_UNAVAILABLE') {
      request.log.error({ requestId: request.id, errorCode: code }, 'Request failed.');
    }
    reply.code(errorDefinitions[code].status).send(errorResponse(request.id, code));
  });

  app.setNotFoundHandler(async () => {
    throw new ApiError('INVALID_REQUEST');
  });

  app.get('/health/ready', async (request,reply) => {
    reply.header('cache-control','no-store');
    if(options.checkReadiness){
      if(!await options.checkReadiness())throw new ApiError('DEPENDENCY_UNAVAILABLE');
    }else if(options.checkReady)await options.checkReady();
    else throw new ApiError('DEPENDENCY_UNAVAILABLE');
    return {requestId:request.id,data:{status:'ready'}};
  });

  app.addHook('onSend', async (request, reply, payload) => {
    reply.header('x-request-id', request.id);
    return payload;
  });

  app.get('/health/live', async (request) => ({
    requestId: request.id,
    data: { status: 'alive' },
  }));

  return app;
}
